#ifndef _OFCOBOL_H
#define _OFCOBOL_H

/* This file, which is supplied in $OFCOB_HOME/include, prototypes the documented
    *  *   */

#ifdef  __cplusplus
extern "C" {
#endif

    int    ofcob_tidy(void);


#ifdef  __cplusplus
}
#endif

#endif /* _OFCOBOL_H */

