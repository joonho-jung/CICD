#include <stdlib.h>
#include <string.h>

extern "C"{
extern int WTO01();
}

int main(){
    WTO01();
   
    return 0;
}
