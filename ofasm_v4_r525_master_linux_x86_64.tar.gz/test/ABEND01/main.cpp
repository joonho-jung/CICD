#include <stdlib.h>
#include <string.h>

extern "C"{
extern int ABEND01();
}

int main(){

    ABEND01();
   
    return 0;
}
