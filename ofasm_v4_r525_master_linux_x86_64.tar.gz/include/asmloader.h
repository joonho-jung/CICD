#ifndef ASMLOADER_H
#define ASMLOADER_H

#ifdef __cplusplus
#include <string>

extern "C" {
/**********************************************************************/
/* asmloader is only for EXEC CICS LOAD command used in cobol program */
/**********************************************************************/

/* extern functions for CICS */
/**
 * @brief get_asm_module_size
 * @param module_path full path of a target module
 * @return byte size of assembler program in cobol program's view
 */
int get_asm_module_size(char* module_path);

/**
 * @brief set_memory_asm_module
 * @param module_path full path of a target module
 * @param cob_ptr already allocated memory pointer from CICS
 * @return 0: success, -1: failed
 */
int set_memory_asm_module(char* module_path, void *cob_ptr);

extern int OFASM_VM_LOAD(const char* name, const char* lib_path);
extern int OFASM_GET_PROGRAM_INFO(const char* name, void* &ptr, int &size);
}

#endif

#endif
